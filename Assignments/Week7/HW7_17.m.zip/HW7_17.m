clear;
signal = [1/sqrt(2) 1/sqrt(2)];
x = [1];
freqz(signal,x);