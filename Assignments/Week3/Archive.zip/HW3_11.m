% 11.b
clear;
close all;

ang_freq = 1:50;
s(ang_freq) = pi*dirac(ang_freq)+(1/(1j*ang_freq)); 

figure;
plot(ang_freq, s(1:length(ang_freq)))
xlim([0 100])
xlabel('Frequency (rad/s)') 
ylabel('Amplitude (mV)') 
title('Unit Step Transform vs Frequency') 



